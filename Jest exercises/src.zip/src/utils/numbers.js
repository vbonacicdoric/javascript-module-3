module.export= { add(a, b) {
  return a + b;
}}
